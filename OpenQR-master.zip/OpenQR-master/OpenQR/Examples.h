#pragma once
void BMPIOTest();
void ImageIOTest();
void FastFourierTransTest();
void GenerateRsCodeword();