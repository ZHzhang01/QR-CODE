#pragma once
#include<string>
#include<bitset>
#include<vector>
#include<algorithm>
#include<cctype>
#include"core.h"
class DataDecoder
{
public:
	DataDecoder();
	~DataDecoder();
	std::string ReverseMap(int i);
};

